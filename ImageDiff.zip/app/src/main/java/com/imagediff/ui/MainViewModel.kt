package com.imagediff.ui

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.imagediff.R
import com.imagediff.data.DiffEngine
import com.imagediff.data.HashCache
import com.imagediff.data.LocalHashProvider
import com.imagediff.data.MediaScope
import com.imagediff.data.MediaStoreSource
import com.imagediff.data.SafSource
import com.imagediff.model.DiffSummary
import com.imagediff.model.LinkMode
import com.imagediff.model.MissingItem
import com.imagediff.model.RemoteIndex
import com.imagediff.model.RemoteIndexException
import com.imagediff.net.NoPeerException
import com.imagediff.net.PeerFinder
import com.imagediff.net.WifiServer
import com.imagediff.net.WiredRemoteIndex
import com.imagediff.net.WirelessRemoteIndex
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException

/**
 * 全部界面状态集中在这里。
 * 状态机：空闲 → 准备中 → 检测中 → 完成 / 已终止 / 出错 → 空闲
 */
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val appContext: Context = app.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val media = MediaStoreSource(appContext)
    private val cache = HashCache(File(appContext.filesDir, "hash_cache.txt"))
    private val saf = SafSource(appContext)
    private val provider = LocalHashProvider(media, cache)
    private val server = WifiServer(appContext, provider) { active -> onServerSession(active) }

    private val cacheReady = CompletableDeferred<Unit>()

    // ------------------------------------------------------------ 界面状态

    var mode: LinkMode by mutableStateOf(LinkMode.WIRELESS)
        private set

    var running: Boolean by mutableStateOf(false)
        private set

    var done: Int by mutableStateOf(0)
        private set

    var total: Int by mutableStateOf(0)
        private set

    var status: String by mutableStateOf("")
        private set

    /** 缺失项（只追加，全部保留，不限数量） */
    val missing = mutableStateListOf<MissingItem>()

    /** 输入框里的文本（可能为空串，表示正在编辑） */
    var durationText: String by mutableStateOf(
        MediaScope.DEFAULT_VIDEO_MAX_DURATION_SECONDS.toString()
    )
        private set

    /** 当前生效的视频时长上限（秒） */
    var videoMaxSeconds: Int by mutableStateOf(MediaScope.DEFAULT_VIDEO_MAX_DURATION_SECONDS)
        private set

    val progressFraction: Float
        get() = if (total <= 0) 0f else (done.toFloat() / total.toFloat()).coerceIn(0f, 1f)

    // ------------------------------------------------------------ 内部状态

    private var runJob: Job? = null
    private var currentRemote: RemoteIndex? = null
    private var stopRequested = false
    private var servingPeer = false

    init {
        status = appContext.getString(R.string.status_idle)

        val savedSeconds = prefs.getInt(
            KEY_VIDEO_SECONDS,
            MediaScope.DEFAULT_VIDEO_MAX_DURATION_SECONDS
        ).coerceIn(
            MediaScope.MIN_VIDEO_MAX_DURATION_SECONDS,
            MediaScope.MAX_VIDEO_MAX_DURATION_SECONDS
        )
        videoMaxSeconds = savedSeconds
        durationText = savedSeconds.toString()

        viewModelScope.launch(Dispatchers.IO) {
            try {
                cache.load()
            } catch (t: Throwable) {
                Log.w(TAG, "载入缓存失败", t)
            } finally {
                cacheReady.complete(Unit)
            }
        }

        // 打开应用即自动监听应答（B 端无需任何操作）
        server.start(viewModelScope)

        refreshIdleStatus()
    }

    // ------------------------------------------------------------ 按钮回调

    fun selectMode(newMode: LinkMode) {
        if (running) return
        mode = newMode
    }

    fun onStart(needTreePicker: () -> Unit) {
        if (running || runJob != null) return

        if (!hasImagesPermission() && !hasVideoPermission() && !hasPartialPermission()) {
            status = appContext.getString(R.string.err_permission)
            return
        }

        when (mode) {
            LinkMode.WIRELESS -> startWireless()
            LinkMode.WIRED -> startWiredFromButton(needTreePicker)
        }
    }

    /** 立即停止，保留已有结果 */
    fun onStop() {
        if (!running && runJob == null) return
        stopRequested = true

        val remote = currentRemote
        runJob?.cancel()
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { remote?.close() }
        }

        status = stoppedText()
        running = false
    }

    fun onPermissionResult() {
        refreshIdleStatus()
    }

    /** 输入框内容变化 */
    fun onDurationTextChange(raw: String) {
        val digits = raw.filter { it.isDigit() }.take(3)
        if (digits.isEmpty()) {
            durationText = ""
            return
        }
        val value = digits.toIntOrNull() ?: return
        val clamped = value.coerceIn(
            MediaScope.MIN_VIDEO_MAX_DURATION_SECONDS,
            MediaScope.MAX_VIDEO_MAX_DURATION_SECONDS
        )
        videoMaxSeconds = clamped
        durationText = clamped.toString()
        prefs.edit().putInt(KEY_VIDEO_SECONDS, clamped).apply()
    }

    /** 输入框失焦：为空则恢复上次有效值 */
    fun onDurationEditingFinished() {
        if (durationText.isBlank()) {
            durationText = videoMaxSeconds.toString()
        }
    }

    fun onTreePicked(uri: Uri?) {
        if (uri == null) {
            status = appContext.getString(R.string.err_no_tree)
            return
        }
        if (running) return

        try {
            appContext.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (t: Throwable) {
            Log.w(TAG, "takePersistableUriPermission 失败：${t.message}")
        }
        prefs.edit().putString(KEY_TREE_URI, uri.toString()).apply()
        startWired(uri)
    }

    // ------------------------------------------------------------ 无线检测

    private fun startWireless() {
        beginRun()
        var remote: WirelessRemoteIndex? = null

        runJob = viewModelScope.launch {
            try {
                cacheReady.await()
                status = appContext.getString(R.string.status_preparing)

                val connection = PeerFinder(appContext).find()
                val wireless = WirelessRemoteIndex(connection)
                remote = wireless
                currentRemote = wireless

                status = appContext.getString(R.string.status_running)
                val summary = DiffEngine(appContext, media, cache).run(
                    remote = wireless,
                    videoMaxDurationMs = videoMaxSeconds * 1000L,
                    onProgress = { d, t ->
                        withContext(Dispatchers.Main) {
                            done = d
                            total = t
                        }
                    },
                    onMissing = { item ->
                        withContext(Dispatchers.Main) {
                            missing.add(item)
                        }
                    }
                )
                finishRun(summary)
            } catch (ce: CancellationException) {
                if (!stopRequested) status = stoppedText()
                throw ce
            } catch (t: Throwable) {
                Log.w(TAG, "无线检测失败", t)
                status = errorText(t)
            } finally {
                closeRemote(remote)
                cache.flush()
                currentRemote = null
                running = false
                runJob = null
            }
        }
    }

    // ------------------------------------------------------------ 有线检测

    private fun startWiredFromButton(needTreePicker: () -> Unit) {
        val saved = prefs.getString(KEY_TREE_URI, null)?.let { Uri.parse(it) }
        if (saved != null && hasTreeAccess(saved)) {
            startWired(saved)
            return
        }
        if (saved != null) clearSavedTree()
        status = appContext.getString(R.string.status_pick_tree)
        needTreePicker()
    }

    private fun startWired(treeUri: Uri) {
        beginRun()
        var remote: WiredRemoteIndex? = null

        runJob = viewModelScope.launch {
            try {
                cacheReady.await()
                status = appContext.getString(R.string.status_preparing)

                val index = saf.buildIndex(treeUri)
                if (index.count == 0) {
                    status = appContext.getString(R.string.err_empty_tree)
                    clearSavedTree()
                    return@launch
                }

                val wired = WiredRemoteIndex(treeUri, index, saf)
                remote = wired
                currentRemote = wired

                status = appContext.getString(R.string.status_running)
                val summary = DiffEngine(appContext, media, cache).run(
                    remote = wired,
                    videoMaxDurationMs = videoMaxSeconds * 1000L,
                    onProgress = { d, t ->
                        withContext(Dispatchers.Main) {
                            done = d
                            total = t
                        }
                    },
                    onMissing = { item ->
                        withContext(Dispatchers.Main) {
                            missing.add(item)
                        }
                    }
                )
                finishRun(summary)
            } catch (ce: CancellationException) {
                if (!stopRequested) status = stoppedText()
                throw ce
            } catch (t: Throwable) {
                Log.w(TAG, "有线检测失败", t)
                status = errorText(t)
                clearSavedTree()
            } finally {
                closeRemote(remote)
                cache.flush()
                currentRemote = null
                running = false
                runJob = null
            }
        }
    }

    // ------------------------------------------------------------ 服务端回调（B 端）

    private fun onServerSession(active: Boolean) {
        viewModelScope.launch(Dispatchers.Main) {
            if (running) return@launch
            if (active) {
                servingPeer = true
                status = appContext.getString(R.string.status_serving)
            } else if (servingPeer) {
                servingPeer = false
                refreshIdleStatus()
            }
        }
    }

    // ------------------------------------------------------------ 内部工具

    private fun beginRun() {
        stopRequested = false
        running = true
        done = 0
        total = 0
        missing.clear()
        status = appContext.getString(R.string.status_preparing)
    }

    private fun finishRun(summary: DiffSummary) {
        status = when {
            summary.total <= 0 -> appContext.getString(R.string.err_empty_local)
            summary.readErrors > 0 -> appContext.getString(
                R.string.status_done_with_errors,
                summary.total,
                summary.missing,
                summary.skippedEdited,
                summary.readErrors
            )

            else -> appContext.getString(
                R.string.status_done,
                summary.total,
                summary.missing,
                summary.skippedEdited
            )
        }
    }

    private fun stoppedText(): String =
        appContext.getString(R.string.status_stopped, total, done, missing.size)

    private fun errorText(t: Throwable): String = when {
        t is NoPeerException -> appContext.getString(R.string.err_no_peer)
        t is SocketTimeoutException -> appContext.getString(R.string.err_timeout)
        t is RemoteIndexException -> appContext.getString(R.string.err_remote_read)
        t is SecurityException -> appContext.getString(R.string.err_permission)
        t is IOException -> appContext.getString(
            R.string.err_generic,
            t.message ?: t.javaClass.simpleName
        )

        else -> appContext.getString(
            R.string.err_generic,
            t.message ?: t.javaClass.simpleName
        )
    }

    private suspend fun closeRemote(remote: RemoteIndex?) {
        if (remote == null) return
        withContext(NonCancellable) {
            runCatching { remote.close() }
        }
    }

    private fun refreshIdleStatus() {
        if (running) return
        status = when {
            !hasImagesPermission() && !hasVideoPermission() && hasPartialPermission() ->
                appContext.getString(R.string.err_permission_partial)

            !hasImagesPermission() && !hasVideoPermission() ->
                appContext.getString(R.string.err_permission)

            !hasLocationPermission() ->
                appContext.getString(R.string.err_location_permission)

            else -> appContext.getString(R.string.status_idle)
        }
    }

    private fun hasImagesPermission(): Boolean = granted(Manifest.permission.READ_MEDIA_IMAGES)

    private fun hasVideoPermission(): Boolean = granted(Manifest.permission.READ_MEDIA_VIDEO)

    private fun hasLocationPermission(): Boolean = granted(Manifest.permission.ACCESS_MEDIA_LOCATION)

    private fun hasPartialPermission(): Boolean =
        granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)

    private fun granted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(appContext, permission) == PackageManager.PERMISSION_GRANTED

    private fun hasTreeAccess(uri: Uri): Boolean = try {
        appContext.contentResolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission
        }
    } catch (t: Throwable) {
        false
    }

    private fun clearSavedTree() {
        val saved = prefs.getString(KEY_TREE_URI, null)
        if (saved != null) {
            try {
                appContext.contentResolver.releasePersistableUriPermission(
                    Uri.parse(saved),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Throwable) {
            }
        }
        prefs.edit().remove(KEY_TREE_URI).apply()
    }

    override fun onCleared() {
        super.onCleared()
        server.stop()
        cache.flush()
        Log.i(TAG, "ViewModel 销毁，已停止无线监听")
    }

    companion object {
        private const val TAG = "MainViewModel"
        private const val PREFS_NAME = "imagediff"
        private const val KEY_TREE_URI = "wired_tree_uri"
        private const val KEY_VIDEO_SECONDS = "video_max_seconds"
    }
}
