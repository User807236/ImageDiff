package com.imagediff.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.imagediff.R
import com.imagediff.model.LinkMode
import com.imagediff.model.MissingItem

private val Accent = Color(0xFF1F6FEB)
private val TextMain = Color(0xFF1A1A1A)
private val TextSub = Color(0xFF333333)
private val DisabledBg = Color(0xFFEFEFEF)
private val DisabledFg = Color(0xFF9A9A9A)
private val LineColor = Color(0xFFE3E4E6)
private val ThumbBg = Color(0xFFF3F4F6)

/**
 * 整个应用只有这一个界面。
 * 可触摸控件：无线 / 有线 / 开始 / 终止 4 个按钮 + 1 个视频时长输入框，其余全部不可点击。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainViewModel, onStart: () -> Unit) {

    Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .windowInsetsPadding(WindowInsets.systemBars)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // 第一行：无线 / 有线
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ActionButton(
                    text = stringResource(R.string.btn_wireless),
                    highlighted = vm.mode == LinkMode.WIRELESS,
                    enabled = !vm.running,
                    modifier = Modifier.weight(1f),
                    onClick = { vm.selectMode(LinkMode.WIRELESS) }
                )
                ActionButton(
                    text = stringResource(R.string.btn_wired),
                    highlighted = vm.mode == LinkMode.WIRED,
                    enabled = !vm.running,
                    modifier = Modifier.weight(1f),
                    onClick = { vm.selectMode(LinkMode.WIRED) }
                )
            }

            Spacer(Modifier.height(12.dp))

            // 第二行：开始 / 终止
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ActionButton(
                    text = stringResource(R.string.btn_start),
                    highlighted = true,
                    enabled = !vm.running,
                    modifier = Modifier.weight(1f),
                    onClick = onStart
                )
                ActionButton(
                    text = stringResource(R.string.btn_stop),
                    highlighted = false,
                    enabled = vm.running,
                    modifier = Modifier.weight(1f),
                    onClick = { vm.onStop() }
                )
            }

            Spacer(Modifier.height(12.dp))

            // 视频时长上限输入框
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.label_video_duration),
                    color = TextSub,
                    fontSize = 13.sp
                )
                Spacer(Modifier.width(10.dp))
                DurationField(
                    text = vm.durationText,
                    onTextChange = vm::onDurationTextChange,
                    onDone = vm::onDurationEditingFinished
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.label_video_duration_unit),
                    color = TextSub,
                    fontSize = 13.sp
                )
            }

            Spacer(Modifier.height(14.dp))

            // 进度条 + n/N
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LinearProgressIndicator(
                    progress = { vm.progressFraction },
                    modifier = Modifier
                        .weight(1f)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = Accent,
                    trackColor = Color(0xFFEDEEF0)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "${vm.done}/${vm.total}",
                    color = TextSub,
                    fontSize = 13.sp
                )
            }

            Spacer(Modifier.height(10.dp))

            // 一行中文状态文字
            Text(
                text = vm.status,
                color = TextSub,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            // 缺失区：3 列网格，可上下滑动，格子本身不可点击
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                state = rememberLazyGridState(),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(items = vm.missing, key = { it.contentUri }) { item ->
                    MissingCell(item)
                }
            }
        }
    }
}

/** 唯一的按钮样式：选中高亮 / 置灰 */
@Composable
private fun ActionButton(
    text: String,
    highlighted: Boolean,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val background = when {
        !enabled -> DisabledBg
        highlighted -> Accent
        else -> Color.White
    }
    val foreground = when {
        !enabled -> DisabledFg
        highlighted -> Color.White
        else -> Accent
    }
    val borderColor = if (enabled) Accent else LineColor

    Box(
        modifier = modifier
            .height(50.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = foreground,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/** 唯一的输入控件：视频时长上限（秒） */
@Composable
private fun DurationField(
    text: String,
    onTextChange: (String) -> Unit,
    onDone: () -> Unit
) {
    val keyboard = LocalSoftwareKeyboardController.current

    Box(
        modifier = Modifier
            .width(76.dp)
            .height(36.dp)
            .background(Color.White, RoundedCornerShape(10.dp))
            .border(1.dp, LineColor, RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        BasicTextField(
            value = text,
            onValueChange = onTextChange,
            singleLine = true,
            textStyle = TextStyle(
                fontSize = 15.sp,
                color = TextMain,
                textAlign = TextAlign.Center
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    keyboard?.hide()
                    onDone()
                }
            ),
            cursorBrush = SolidColor(Accent),
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { state ->
                    if (!state.isFocused) onDone()
                }
                .padding(horizontal = 6.dp)
        )
    }
}

/** 一格：缩略图 + 完整文件名（含扩展名，可换行） */
@Composable
private fun MissingCell(item: MissingItem) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Thumbnail(contentUri = item.contentUri)
        Text(
            text = item.displayName,
            color = TextMain,
            fontSize = 11.sp,
            lineHeight = 14.sp,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun Thumbnail(contentUri: String) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(initialValue = null, contentUri) {
        value = ThumbnailCache.load(context, contentUri)?.asImageBitmap()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(ThumbBg)
    ) {
        val image = bitmap
        if (image != null) {
            Image(
                bitmap = image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
