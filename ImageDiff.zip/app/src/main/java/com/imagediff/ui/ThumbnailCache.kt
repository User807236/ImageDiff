package com.imagediff.ui

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * 缩略图缓存（图片、GIF、视频共用；视频由系统截一帧）。
 * · loadThumbnail 由系统生成，不读原图
 * · LruCache 按字节数限制（堆的 1/8，最多 64MB）
 * · 最多 4 个并发解码；失败返回 null（界面显示灰色占位块），不崩溃
 */
object ThumbnailCache {

    private const val TAG = "ThumbnailCache"

    private val maxBytes: Int =
        (Runtime.getRuntime().maxMemory() / 8).coerceAtMost(64L * 1024 * 1024).toInt()

    private val lru = object : LruCache<String, Bitmap>(maxBytes) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private val semaphore = Semaphore(4)

    suspend fun load(context: Context, contentUri: String): Bitmap? {
        lru.get(contentUri)?.let { return it }

        return semaphore.withPermit {
            lru.get(contentUri)?.let { return@withPermit it }

            val bitmap = withContext(Dispatchers.IO) {
                try {
                    context.contentResolver.loadThumbnail(
                        Uri.parse(contentUri),
                        Size(256, 256),
                        null
                    )
                } catch (t: Throwable) {
                    Log.d(TAG, "缩略图加载失败 $contentUri：${t.message}")
                    null
                }
            }

            if (bitmap != null) lru.put(contentUri, bitmap)
            bitmap
        }
    }
}
