package com.imagediff.data

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import com.imagediff.model.ImageMeta
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.IOException
import java.security.MessageDigest

/**
 * 媒体读取（图片 + 视频，覆盖 MediaStore.Images 与 MediaStore.Video）：
 *
 * · A 端枚举（countImages / forEachPage）：图片全收；视频按白名单 + 输入框设定的时长上限收。
 * · B 端查询（countBySize / findBySize）：同样收图片与视频，但**不限时长**，
 *   否则 A 端的视频在对端索引里查不到，会被误判成缺失。
 * · is_pending=0 排除未写完的，is_trashed=0 排除回收站。
 * · keyset 分页（_id > lastId LIMIT n）流式读取，几万条也不会 OOM。
 */
class MediaStoreSource(private val context: Context) {

    suspend fun forEachPage(
        pageSize: Int = 400,
        videoMaxDurationMs: Long = MediaScope.DEFAULT_VIDEO_MAX_DURATION_MS,
        onPage: suspend (List<ImageMeta>) -> Unit
    ) = withContext(Dispatchers.IO) {
        val base = baseSelection(withDurationLimit = true, videoMaxDurationMs = videoMaxDurationMs)
        var lastId = 0L
        while (true) {
            val page = queryPage(base, lastId, pageSize)
            if (page.isEmpty()) break
            onPage(page)
            lastId = page.last().id
            if (page.size < pageSize) break
        }
    }

    /** A 端待处理总数（= 进度分母 N），与分页使用完全相同的过滤条件 */
    suspend fun countImages(
        videoMaxDurationMs: Long = MediaScope.DEFAULT_VIDEO_MAX_DURATION_MS
    ): Int = withContext(Dispatchers.IO) {
        var cursor: Cursor? = null
        try {
            val selection = baseSelection(true, videoMaxDurationMs)
            cursor = context.contentResolver.query(
                COLLECTION,
                arrayOf(MediaStore.MediaColumns._ID),
                selection,
                null,
                null
            )
            cursor?.count ?: 0
        } catch (t: Throwable) {
            Log.w(TAG, "统计数量失败", t)
            0
        } finally {
            closeQuietly(cursor)
        }
    }

    /** B 端查询：本机有多少个“字节数 == size”的可比文件（不限视频时长） */
    suspend fun countBySize(size: Long): Int = withContext(Dispatchers.IO) {
        var cursor: Cursor? = null
        try {
            cursor = context.contentResolver.query(
                COLLECTION,
                arrayOf(MediaStore.MediaColumns._ID),
                sizeSelection(size),
                sizeArgs(size),
                null
            )
            cursor?.count ?: 0
        } catch (t: Throwable) {
            Log.w(TAG, "按大小统计失败 size=$size", t)
            0
        } finally {
            closeQuietly(cursor)
        }
    }

    /** B 端查询：取出“字节数 == size”的可比文件（最多 limit 个，不限视频时长） */
    suspend fun findBySize(size: Long, limit: Int): List<ImageMeta> = withContext(Dispatchers.IO) {
        var cursor: Cursor? = null
        try {
            val sort = "${MediaStore.MediaColumns._ID} ASC LIMIT $limit"
            cursor = context.contentResolver.query(
                COLLECTION,
                PROJECTION,
                sizeSelection(size),
                sizeArgs(size),
                sort
            )
            cursor?.let { readAll(it) } ?: emptyList()
        } catch (t: Throwable) {
            Log.w(TAG, "按大小查询失败 size=$size", t)
            emptyList()
        } finally {
            closeQuietly(cursor)
        }
    }

    /**
     * 计算原始文件字节的 SHA-256（图片、GIF、视频都走这里）。
     * 必须 setRequireOriginal，否则系统会返回抹掉 EXIF 定位的脱敏字节。
     */
    suspend fun sha256(uri: Uri): String = withContext(Dispatchers.IO) {
        val target = try {
            MediaStore.setRequireOriginal(uri)
        } catch (t: Throwable) {
            uri
        }
        val input = context.contentResolver.openInputStream(target)
            ?: throw IOException("无法打开文件：$uri")
        input.use { stream ->
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(BUFFER_SIZE)
            while (true) {
                // 每读一块就检查取消：64KB 一块，点「终止」后 1 秒内必定停下
                currentCoroutineContext().ensureActive()
                val n = stream.read(buffer)
                if (n < 0) break
                if (n > 0) digest.update(buffer, 0, n)
            }
            digest.digest().toHexString()
        }
    }

    // ---------------------------------------------------------------- 内部实现

    private fun queryPage(base: String, lastId: Long, limit: Int): List<ImageMeta> {
        var cursor: Cursor? = null
        try {
            val selection = "$base AND ${MediaStore.MediaColumns._ID} > ?"
            val args = arrayOf(lastId.toString())
            val sort = "${MediaStore.MediaColumns._ID} ASC LIMIT $limit"
            cursor = context.contentResolver.query(COLLECTION, PROJECTION, selection, args, sort)
            return cursor?.let { readAll(it) } ?: emptyList()
        } catch (t: Throwable) {
            Log.w(TAG, "分页读取失败 lastId=$lastId", t)
            return emptyList()
        } finally {
            closeQuietly(cursor)
        }
    }

    private fun readAll(cursor: Cursor): List<ImageMeta> {
        val out = ArrayList<ImageMeta>(cursor.count.coerceAtLeast(0))
        val idIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
        val nameIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
        val sizeIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
        val widthIdx = cursor.getColumnIndex(MediaStore.MediaColumns.WIDTH)
        val heightIdx = cursor.getColumnIndex(MediaStore.MediaColumns.HEIGHT)
        val mtimeIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
        val typeIdx = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
        val mimeIdx = cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)

        while (cursor.moveToNext()) {
            val id = cursor.getLong(idIdx)
            val name = cursor.getString(nameIdx) ?: ""
            val size = if (cursor.isNull(sizeIdx)) 0L else cursor.getLong(sizeIdx)
            val width = if (widthIdx >= 0 && !cursor.isNull(widthIdx)) cursor.getInt(widthIdx) else 0
            val height = if (heightIdx >= 0 && !cursor.isNull(heightIdx)) cursor.getInt(heightIdx) else 0
            val mtime = if (cursor.isNull(mtimeIdx)) 0L else cursor.getLong(mtimeIdx)
            val mediaType = if (cursor.isNull(typeIdx)) MediaScope.MEDIA_TYPE_IMAGE else cursor.getInt(typeIdx)
            val mime = if (mimeIdx >= 0 && !cursor.isNull(mimeIdx)) cursor.getString(mimeIdx) ?: "" else ""
            val isVideo = mediaType == MediaScope.MEDIA_TYPE_VIDEO

            out.add(
                ImageMeta(
                    id = id,
                    uri = contentUriFor(isVideo, id),
                    displayName = name,
                    size = size,
                    width = width,
                    height = height,
                    dateModified = mtime,
                    isVideo = isVideo,
                    mimeType = mime
                )
            )
        }
        return out
    }

    private fun contentUriFor(isVideo: Boolean, id: Long): Uri =
        if (isVideo) {
            ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
        } else {
            ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
        }

    private fun sizeSelection(size: Long): String {
        val base = baseSelection(withDurationLimit = false, videoMaxDurationMs = 0L)
        return if (size > 0L) {
            "$base AND ${MediaStore.MediaColumns.SIZE} = ?"
        } else {
            "$base AND (${MediaStore.MediaColumns.SIZE} IS NULL OR ${MediaStore.MediaColumns.SIZE} <= 0)"
        }
    }

    private fun sizeArgs(size: Long): Array<String>? =
        if (size > 0L) arrayOf(size.toString()) else null

    private fun baseSelection(withDurationLimit: Boolean, videoMaxDurationMs: Long): String =
        buildString {
            append(MediaStore.MediaColumns.IS_PENDING).append("=0")
            append(" AND ").append(MediaStore.MediaColumns.IS_TRASHED).append("=0")
            append(" AND (")
            append(MediaStore.Files.FileColumns.MEDIA_TYPE)
                .append('=').append(MediaScope.MEDIA_TYPE_IMAGE)

            if (MediaScope.INCLUDE_VIDEO && MediaScope.VIDEO_MIME.isNotEmpty()) {
                append(" OR (")
                append(MediaStore.Files.FileColumns.MEDIA_TYPE)
                    .append('=').append(MediaScope.MEDIA_TYPE_VIDEO)

                if (withDurationLimit && videoMaxDurationMs > 0L) {
                    append(" AND (")
                    append(MediaStore.MediaColumns.DURATION).append(" IS NULL OR ")
                    append(MediaStore.MediaColumns.DURATION)
                        .append("<=").append(videoMaxDurationMs)
                    append(')')
                }

                append(" AND ").append(MediaStore.MediaColumns.MIME_TYPE).append(" IN (")
                append(MediaScope.VIDEO_MIME.joinToString(",") { "'$it'" })
                append("))")
            }
            append(')')
        }

    private fun closeQuietly(cursor: Cursor?) {
        try {
            cursor?.close()
        } catch (_: Throwable) {
        }
    }

    companion object {
        private const val TAG = "MediaStoreSource"
        private const val BUFFER_SIZE = 64 * 1024

        /** 共享存储全部卷（含所有图片 + 视频） */
        private val COLLECTION: Uri = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)

        private val PROJECTION = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.MediaColumns.MIME_TYPE
        )
    }
}
