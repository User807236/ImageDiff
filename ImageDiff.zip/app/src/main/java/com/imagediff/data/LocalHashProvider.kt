package com.imagediff.data

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.LinkedHashMap

/**
 * 供“无线模式下的对端”查询本机指纹（B 端逻辑）。
 * 只返回 文件大小 + SHA-256，绝不返回文件内容。
 */
class LocalHashProvider(
    private val media: MediaStoreSource,
    private val cache: HashCache
) {

    private val memo = object : LinkedHashMap<Long, List<String>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, List<String>>): Boolean =
            size > MEMO_LIMIT
    }

    private val lock = Mutex()

    suspend fun countBySize(size: Long): Int = media.countBySize(size)

    suspend fun hashesBySize(size: Long): List<String> = lock.withLock {
        memo[size]?.let { return@withLock it }

        val items = media.findBySize(size, MAX_PER_SIZE)
        val result = ArrayList<String>(items.size)
        for (meta in items) {
            val key = meta.cacheKey
            val cached = cache.get(key, meta.size, meta.dateModified)
            val sha = cached?.sha ?: runCatching { media.sha256(meta.uri) }.getOrNull()
            if (sha != null) {
                if (cached?.sha == null) {
                    cache.markHash(key, meta.size, meta.dateModified, sha)
                }
                result.add(sha)
            }
        }
        memo[size] = result
        result
    }

    suspend fun containsUnknownSizeHash(hash: String): Boolean =
        hashesBySize(0L).contains(hash)

    companion object {
        /** 同一尺寸最多比对 2000 个，防止极端情况拖垮内存 */
        private const val MAX_PER_SIZE = 2000
        private const val MEMO_LIMIT = 256
    }
}
