package com.imagediff.data

import android.provider.MediaStore

/**
 * 纳入比对范围的媒体类型 / 视频时长上限 —— 集中配置在这里。
 *
 * · GIF（GIF87a / GIF89a）、APNG、动态 WebP、HEIC、AVIF 等
 *   在媒体库里都归类为 image/*，全部默认纳入，无需配置。
 * · 视频（mp4/mov/3gp/mkv/webm/m4v）通过 INCLUDE_VIDEO 打开，
 *   时长上限由界面输入框决定（默认 20 秒，最大 10 分钟）。
 */
object MediaScope {

    const val INCLUDE_VIDEO = true

    /** 输入框默认值：20 秒 */
    const val DEFAULT_VIDEO_MAX_DURATION_SECONDS = 20

    /** 输入框允许的最小值：1 秒 */
    const val MIN_VIDEO_MAX_DURATION_SECONDS = 1

    /** 输入框允许的最大值：600 秒 = 10 分钟 */
    const val MAX_VIDEO_MAX_DURATION_SECONDS = 600

    const val DEFAULT_VIDEO_MAX_DURATION_MS = DEFAULT_VIDEO_MAX_DURATION_SECONDS * 1000L

    /** 纳入的视频 mime 白名单 */
    val VIDEO_MIME: Set<String> = setOf(
        "video/mp4",
        "video/quicktime",
        "video/3gpp",
        "video/3gpp2",
        "video/webm",
        "video/x-matroska",
        "video/x-msvideo"
    )

    /** 纳入的图片扩展名（有线 / SAF 枚举用） */
    val IMAGE_SUFFIXES: List<String> = listOf(
        ".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif", ".avif",
        ".gif", ".bmp", ".dng", ".apng", ".tif", ".tiff"
    )

    /** 纳入的视频扩展名（有线 / SAF 枚举用） */
    val VIDEO_SUFFIXES: List<String> = listOf(
        ".mp4", ".m4v", ".mov", ".3gp", ".3g2", ".mkv", ".webm", ".avi"
    )

    const val MEDIA_TYPE_IMAGE = MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
    const val MEDIA_TYPE_VIDEO = MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
}
