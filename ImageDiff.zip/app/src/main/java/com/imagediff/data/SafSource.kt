package com.imagediff.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.IOException
import java.security.MessageDigest
import java.util.Locale

/**
 * 有线模式：通过 SAF（ACTION_OPEN_DOCUMENT_TREE）递归枚举对端存储里的
 * 图片、GIF/动图、视频。
 *
 * 只记录 documentId + 文件大小，不读内容；
 * 索引结构：size → [documentId...]，另加“大小未知”桶（MTP 可能不给 SIZE）。
 */
class SafSource(private val context: Context) {

    class Index {
        val bySize = HashMap<Long, MutableList<String>>()
        val unknownSize = ArrayList<String>()

        var count = 0
            private set

        fun add(size: Long, documentId: String) {
            if (size > 0L) {
                bySize.getOrPut(size) { ArrayList() }.add(documentId)
            } else {
                unknownSize.add(documentId)
            }
            count++
        }
    }

    suspend fun buildIndex(treeUri: Uri): Index = withContext(Dispatchers.IO) {
        val index = Index()
        val rootId = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (t: Throwable) {
            throw IOException("无法打开所选存储", t)
        }
        walk(treeUri, rootId, index)
        Log.i(TAG, "对端索引完成：${index.count} 个文件")
        index
    }

    private suspend fun walk(treeUri: Uri, parentDocumentId: String, index: Index) {
        val childrenUri =
            DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocumentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )

        val cursor = try {
            context.contentResolver.query(childrenUri, projection, null, null, null)
        } catch (t: Throwable) {
            Log.w(TAG, "读取目录失败：$parentDocumentId ${t.message}")
            null
        }

        cursor?.use { c ->
            val idxId = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val idxName = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val idxMime = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
            val idxSize = c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
            if (idxId < 0) return

            while (c.moveToNext()) {
                val documentId = c.getString(idxId) ?: continue
                val name = if (idxName >= 0) c.getString(idxName) ?: "" else ""
                val mime = if (idxMime >= 0) c.getString(idxMime) ?: "" else ""
                val size = if (idxSize >= 0 && !c.isNull(idxSize)) c.getLong(idxSize) else 0L

                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walk(treeUri, documentId, index)
                } else if (isComparableFile(name, mime)) {
                    index.add(size, documentId)
                }
            }
        }
    }

    /**
     * 有线模式：MIME 与扩展名**都**判断
     * （MTP 设备常把图片报成 application/octet-stream，只能靠扩展名）。
     */
    private fun isComparableFile(name: String, mime: String): Boolean {
        val lowerMime = mime.lowercase(Locale.ROOT)
        if (lowerMime.startsWith("image/")) return true
        if (MediaScope.INCLUDE_VIDEO && MediaScope.VIDEO_MIME.contains(lowerMime)) return true

        val lower = name.lowercase(Locale.ROOT)
        if (MediaScope.IMAGE_SUFFIXES.any { lower.endsWith(it) }) return true
        if (MediaScope.INCLUDE_VIDEO && MediaScope.VIDEO_SUFFIXES.any { lower.endsWith(it) }) {
            return true
        }
        return false
    }

    /** 读取对端某个文件的 SHA-256（流式，不缓存整文件） */
    suspend fun sha256(treeUri: Uri, documentId: String): String = withContext(Dispatchers.IO) {
        val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId)
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IOException("无法打开对端文件")
        input.use { stream ->
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(BUFFER_SIZE)
            while (true) {
                // 拔线 / 点「终止」时立即中断
                currentCoroutineContext().ensureActive()
                val n = stream.read(buffer)
                if (n < 0) break
                if (n > 0) digest.update(buffer, 0, n)
            }
            digest.digest().toHexString()
        }
    }

    companion object {
        private const val TAG = "SafSource"
        private const val BUFFER_SIZE = 64 * 1024
    }
}
