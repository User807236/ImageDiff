package com.imagediff.data

private val HEX_CHARS = "0123456789abcdef".toCharArray()

/** 字节数组转小写十六进制字符串（SHA-256 指纹） */
fun ByteArray.toHexString(): String {
    val sb = StringBuilder(size * 2)
    for (b in this) {
        val v = b.toInt() and 0xFF
        sb.append(HEX_CHARS[v ushr 4])
        sb.append(HEX_CHARS[v and 0x0F])
    }
    return sb.toString()
}
