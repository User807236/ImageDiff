package com.imagediff.data

import android.util.Log
import java.io.File

/**
 * 本地指纹缓存（纯文本，可随时删除重建）。
 *
 * 每行格式：contentUri|size|mtime|sha256|editedKnown|edited
 *   · 键使用**完整 URI**（图片与视频的 media id 可能撞，不能用 id）
 *   · size 或 mtime 变化 → 整条缓存失效
 *   · sha 为 "-" 表示“还没算过哈希”
 *   · editedKnown 为 0 表示“还没做过已编辑判定”
 */
class HashCache(private val file: File) {

    data class Entry(
        val size: Long,
        val mtime: Long,
        val sha: String?,
        val edited: Boolean,
        val editedKnown: Boolean
    )

    private val map = HashMap<String, Entry>()
    private val lock = Any()

    @Volatile
    private var dirty = false

    /** App 启动时在后台线程调用一次 */
    fun load() {
        if (!file.exists()) return
        try {
            val loaded = HashMap<String, Entry>()
            file.bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { line ->
                    if (line.isBlank()) return@forEach
                    val p = line.split('|')
                    if (p.size < 6) return@forEach
                    val key = p[0]
                    if (key.isBlank()) return@forEach
                    val size = p[1].toLongOrNull() ?: return@forEach
                    val mtime = p[2].toLongOrNull() ?: return@forEach
                    val sha = p[3].takeIf { it != "-" && it.isNotEmpty() }
                    val editedKnown = p[4] == "1"
                    val edited = p[5] == "1"
                    loaded[key] = Entry(size, mtime, sha, edited, editedKnown)
                }
            }
            synchronized(lock) {
                map.clear()
                map.putAll(loaded)
            }
            Log.i(TAG, "哈希缓存载入 ${loaded.size} 条")
        } catch (t: Throwable) {
            Log.w(TAG, "读取哈希缓存失败", t)
        }
    }

    fun get(key: String, size: Long, mtime: Long): Entry? {
        synchronized(lock) {
            val e = map[key] ?: return null
            if (e.size != size || e.mtime != mtime) {
                map.remove(key)
                dirty = true
                return null
            }
            return e
        }
    }

    fun markEditedChecked(key: String, size: Long, mtime: Long, edited: Boolean) {
        synchronized(lock) {
            val old = map[key]
            map[key] = if (old != null && old.size == size && old.mtime == mtime) {
                old.copy(edited = edited, editedKnown = true)
            } else {
                Entry(size, mtime, null, edited, true)
            }
            dirty = true
        }
    }

    fun markHash(key: String, size: Long, mtime: Long, sha: String) {
        synchronized(lock) {
            val old = map[key]
            map[key] = if (old != null && old.size == size && old.mtime == mtime) {
                old.copy(sha = sha)
            } else {
                Entry(size, mtime, sha, false, false)
            }
            dirty = true
        }
    }

    /** 落盘（线程安全，可随时多次调用） */
    fun flush() {
        val snapshot: List<Map.Entry<String, Entry>>
        synchronized(lock) {
            if (!dirty) return
            snapshot = map.entries.toList()
            dirty = false
        }
        try {
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.bufferedWriter(Charsets.UTF_8).use { w ->
                for ((key, e) in snapshot) {
                    w.write(
                        buildString {
                            append(key)
                            append('|')
                            append(e.size)
                            append('|')
                            append(e.mtime)
                            append('|')
                            append(e.sha ?: "-")
                            append('|')
                            append(if (e.editedKnown) "1" else "0")
                            append('|')
                            append(if (e.edited) "1" else "0")
                        }
                    )
                    w.newLine()
                }
            }
            if (file.exists()) file.delete()
            if (!tmp.renameTo(file)) {
                tmp.copyTo(file, overwrite = true)
                tmp.delete()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "写入哈希缓存失败", t)
        }
    }

    companion object {
        private const val TAG = "HashCache"
    }
}
