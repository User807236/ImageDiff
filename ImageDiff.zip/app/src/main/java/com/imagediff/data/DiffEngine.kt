package com.imagediff.data

import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.imagediff.model.DiffSummary
import com.imagediff.model.ImageMeta
import com.imagediff.model.MissingItem
import com.imagediff.model.RemoteIndex
import com.imagediff.model.RemoteIndexException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * 比对引擎（A 端）：
 *
 *   生产者（分页读 MediaStore） → Channel(128) → 4 个 worker 并行处理 → 缺失回调
 *
 * 单条媒体的处理顺序（严格按需求）：
 *   1. 已编辑判定（图片 / GIF / 视频各自规则），命中 → 跳过
 *   2. 大小预筛：对端没有同尺寸候选 → 直接判缺失（不算哈希）
 *   3. 流式计算本机原始字节 SHA-256（有缓存则复用）
 *   4. 取对端同尺寸候选的哈希集合比对
 *
 * 进度 n 在 finally 中自增，保证每条必然计入，最终走到 N/N。
 */
class DiffEngine(
    private val context: Context,
    private val media: MediaStoreSource,
    private val cache: HashCache,
    private val workerCount: Int = 4
) {

    private enum class Outcome { PRESENT, MISSING, EDITED }

    suspend fun run(
        remote: RemoteIndex,
        videoMaxDurationMs: Long,
        onProgress: suspend (done: Int, total: Int) -> Unit,
        onMissing: suspend (item: MissingItem) -> Unit
    ): DiffSummary = coroutineScope {

        val total = media.countImages(videoMaxDurationMs)
        onProgress(0, total)
        if (total <= 0) return@coroutineScope DiffSummary(0, 0, 0, 0)

        val done = AtomicInteger(0)
        val missingCount = AtomicInteger(0)
        val skippedEdited = AtomicInteger(0)
        val readErrors = AtomicInteger(0)
        val lastPush = AtomicLong(0L)

        suspend fun pushProgress() {
            val d = done.get()
            val now = SystemClock.elapsedRealtime()
            if (d >= total || now - lastPush.get() >= 80L) {
                lastPush.set(now)
                onProgress(d.coerceAtMost(total), total)
            }
        }

        val queue = Channel<ImageMeta>(capacity = 128)

        val producer = launch(Dispatchers.IO) {
            try {
                media.forEachPage(pageSize = 400, videoMaxDurationMs = videoMaxDurationMs) { page ->
                    for (m in page) {
                        if (!isActive) break
                        queue.send(m)
                    }
                }
            } catch (t: CancellationException) {
                throw t
            } catch (t: Throwable) {
                Log.w(TAG, "读取相册中断：${t.message}")
            } finally {
                queue.close()
            }
        }

        val workers = (1..workerCount).map {
            launch(Dispatchers.IO) {
                while (true) {
                    // 显式 receiveCatching：通道关闭即退出，且可被取消
                    val meta = queue.receiveCatching().getOrNull() ?: break
                    try {
                        currentCoroutineContext().ensureActive()
                        when (process(meta, remote)) {
                            Outcome.PRESENT -> Unit
                            Outcome.EDITED -> skippedEdited.incrementAndGet()
                            Outcome.MISSING -> {
                                missingCount.incrementAndGet()
                                onMissing(
                                    MissingItem(
                                        id = meta.id,
                                        contentUri = meta.uri.toString(),
                                        displayName = meta.displayName,
                                        size = meta.size,
                                        isVideo = meta.isVideo
                                    )
                                )
                            }
                        }
                    } catch (ce: CancellationException) {
                        throw ce
                    } catch (t: Throwable) {
                        if (t is RemoteIndexException) {
                            // 对端断开 / 读取失败：整体中断，避免把剩余全部误判成缺失
                            throw t
                        }
                        readErrors.incrementAndGet()
                        Log.w(TAG, "处理失败 id=${meta.id}：${t.message}")
                    } finally {
                        done.incrementAndGet()
                        withContext(NonCancellable) {
                            try {
                                pushProgress()
                            } catch (_: Throwable) {
                            }
                        }
                    }
                }
            }
        }

        workers.joinAll()
        producer.cancel()
        cache.flush()
        onProgress(total, total)

        DiffSummary(
            total = total,
            missing = missingCount.get(),
            skippedEdited = skippedEdited.get(),
            readErrors = readErrors.get()
        )
    }

    private suspend fun process(meta: ImageMeta, remote: RemoteIndex): Outcome {
        val key = meta.cacheKey
        val cached = cache.get(key, meta.size, meta.dateModified)

        // 1) 已编辑判定（图像 / GIF / 视频各自规则，结果写缓存）
        val edited: Boolean = if (cached != null && cached.editedKnown) {
            cached.edited
        } else {
            val result = EditJudge.judge(context, meta)
            cache.markEditedChecked(key, meta.size, meta.dateModified, result)
            result
        }
        if (edited) return Outcome.EDITED

        // 2) 大小预筛：对端没有同尺寸候选 → 直接缺失，不算哈希
        if (meta.size > 0L && !remote.hasSizeCandidate(meta.size)) {
            return Outcome.MISSING
        }

        // 3) 计算本机原始字节 SHA-256（有缓存则复用）
        val hash = cached?.sha ?: media.sha256(meta.uri).also {
            cache.markHash(key, meta.size, meta.dateModified, it)
        }

        // 4) 与对端指纹比对
        val present = if (meta.size > 0L) {
            hash in remote.hashesForSize(meta.size)
        } else {
            remote.containsUnknownSizeHash(hash)
        }

        return if (present) Outcome.PRESENT else Outcome.MISSING
    }

    companion object {
        private const val TAG = "DiffEngine"
    }
}
