package com.imagediff.data

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.util.Log

/**
 * GIF / APNG 等动图的元数据读取。
 *
 * GIF：解析注释扩展块（0x21 0xFE）与 XMP 应用扩展块（0x21 0xFF "XMP DataXMP"）。
 * 只读文件开头有限字节，绝不整文件入内存；任何解析异常都返回 null（= 不判定为已编辑）。
 */
object GifInspector {

    private const val TAG = "GifInspector"
    private const val MAX_READ = 512 * 1024
    private const val MAX_TEXT = 64 * 1024
    private const val MAX_STEPS = 200_000

    data class GifInfo(
        val commentText: String?,
        val xmp: String?
    )

    fun read(context: Context, uri: Uri): GifInfo? {
        val target = try {
            MediaStore.setRequireOriginal(uri)
        } catch (t: Throwable) {
            uri
        }
        var pfd: android.os.ParcelFileDescriptor? = null
        try {
            pfd = context.contentResolver.openFileDescriptor(target, "r") ?: return null
            val data = android.os.ParcelFileDescriptor.AutoCloseInputStream(pfd).use { stream ->
                val buffer = ByteArray(MAX_READ)
                var total = 0
                while (total < buffer.size) {
                    val n = stream.read(buffer, total, buffer.size - total)
                    if (n <= 0) break
                    total += n
                }
                buffer.copyOf(total)
            }
            pfd = null
            if (data.size < 14) return null
            return parse(data)
        } catch (t: Throwable) {
            Log.d(TAG, "解析 GIF 失败：${t.message}")
            return null
        } finally {
            try {
                pfd?.close()
            } catch (_: Throwable) {
            }
        }
    }

    private fun parse(data: ByteArray): GifInfo {
        if (data.size < 14) return GifInfo(null, null)
        if (data[0] != 'G'.code.toByte() ||
            data[1] != 'I'.code.toByte() ||
            data[2] != 'F'.code.toByte()
        ) {
            return GifInfo(null, null)
        }

        val comments = StringBuilder()
        var xmp: String? = null

        // 6 字节头 + 7 字节逻辑屏幕描述符
        var pos = 13
        var steps = 0

        while (pos < data.size && steps++ < MAX_STEPS) {
            val marker = data[pos].toInt() and 0xFF
            when (marker) {
                0x3B -> break // trailer

                0x2C -> { // 图像描述符
                    pos += 10
                    if (pos >= data.size) break
                    pos += 1 // LZW minimum code size
                    pos = skipSubBlocks(data, pos)
                }

                0x21 -> { // 扩展块
                    if (pos + 1 >= data.size) break
                    val label = data[pos + 1].toInt() and 0xFF
                    pos += 2
                    when (label) {
                        0xFE -> { // 注释
                            val sb = StringBuilder()
                            pos = readSubBlocks(data, pos, sb)
                            comments.append(sb)
                        }

                        0xFF -> { // 应用扩展
                            if (pos + 11 > data.size) break
                            val identifier = String(
                                data, pos, 11, Charsets.ISO_8859_1
                            )
                            pos += 11
                            if (identifier.startsWith("XMP Data")) {
                                val sb = StringBuilder()
                                pos = readSubBlocks(data, pos, sb)
                                xmp = sb.toString().take(MAX_TEXT)
                            } else {
                                pos = skipSubBlocks(data, pos)
                            }
                        }

                        else -> pos = skipSubBlocks(data, pos)
                    }
                }

                else -> break
            }
        }

        val comment = comments.toString().take(MAX_TEXT)
        return GifInfo(
            commentText = comment.takeIf { it.isNotBlank() },
            xmp = xmp?.takeIf { it.isNotBlank() }
        )
    }

    /** 跳过一串 sub-block，返回下一个位置 */
    private fun skipSubBlocks(data: ByteArray, start: Int): Int {
        var pos = start
        var guard = 0
        while (pos < data.size && guard++ < MAX_STEPS) {
            val len = data[pos].toInt() and 0xFF
            pos += 1
            if (len == 0) return pos
            pos += len
        }
        return data.size
    }

    /** 读取一串 sub-block 的内容 */
    private fun readSubBlocks(data: ByteArray, start: Int, out: StringBuilder): Int {
        var pos = start
        var guard = 0
        while (pos < data.size && guard++ < MAX_STEPS) {
            val len = data[pos].toInt() and 0xFF
            pos += 1
            if (len == 0) return pos
            if (pos + len > data.size) return data.size
            if (out.length < MAX_TEXT) {
                out.append(String(data, pos, len, Charsets.ISO_8859_1))
            }
            pos += len
        }
        return data.size
    }
}
