package com.imagediff.data

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import java.util.Locale

/** 判断“是否已编辑”所需的 EXIF / XMP 摘要 */
data class ExifInfo(
    val software: String?,
    val xmp: String?,
    val dateTime: Long,
    val dateTimeOriginal: Long,
    val hasExif: Boolean
)

object ExifInspector {

    private const val TAG = "ExifInspector"
    private const val ONE_MINUTE_MS = 60_000L

    /**
     * 读取一张图片的 EXIF / XMP 摘要（JPEG / PNG / WebP / HEIC）。
     * 必须 setRequireOriginal，否则系统会抹掉定位信息，哈希也会对不上。
     */
    fun read(context: Context, uri: Uri): ExifInfo {
        val target = try {
            MediaStore.setRequireOriginal(uri)
        } catch (t: Throwable) {
            uri
        }

        // 1) 优先 FileDescriptor：只在构造时随机读文件头，不整图入内存
        try {
            context.contentResolver.openFileDescriptor(target, "r")?.use { pfd ->
                return snapshot(ExifInterface(pfd.fileDescriptor))
            }
        } catch (t: Throwable) {
            Log.d(TAG, "FD 方式读取 EXIF 失败：${t.message}")
        }

        // 2) 回退到输入流（部分 provider 返回管道，不支持 seek）
        try {
            context.contentResolver.openInputStream(target)?.use { input ->
                return snapshot(ExifInterface(input))
            }
        } catch (t: Throwable) {
            Log.d(TAG, "流方式读取 EXIF 失败：${t.message}")
        }

        return ExifInfo(null, null, -1L, -1L, false)
    }

    private fun snapshot(exif: ExifInterface): ExifInfo {
        val software = safeAttribute(exif, ExifInterface.TAG_SOFTWARE)
        val xmp = safeAttribute(exif, ExifInterface.TAG_XMP)
        val dateTime = try {
            exif.getDateTime()
        } catch (t: Throwable) {
            -1L
        }
        val dateTimeOriginal = try {
            exif.getDateTimeOriginal()
        } catch (t: Throwable) {
            -1L
        }
        val hasExif = software != null || xmp != null || dateTime > 0L || dateTimeOriginal > 0L
        return ExifInfo(software, xmp, dateTime, dateTimeOriginal, hasExif)
    }

    private fun safeAttribute(exif: ExifInterface, tag: String): String? = try {
        exif.getAttribute(tag)?.takeIf { it.isNotBlank() }
    } catch (t: Throwable) {
        null
    }

    /**
     * ============ 图片“已编辑”判定 ============
     * ① EXIF Software 或 XMP 含修图软件名；
     * ② EXIF DateTime 比 DateTimeOriginal 晚超过 1 分钟；
     * ③ XMP 含编辑历史 / 调色参数；
     * ④ 文件名带编辑标记。
     *
     * 无 EXIF 的截图、下载图不算已编辑。
     */
    fun judgeEdited(info: ExifInfo, fileName: String): Boolean {
        val lowerName = fileName.lowercase(Locale.ROOT)

        val software = (info.software ?: "").lowercase(Locale.ROOT)
        if (software.isNotEmpty() && EditKeywords.SOFTWARE.any { software.contains(it) }) {
            return true
        }

        val xmp = info.xmp.orEmpty()
        if (xmp.isNotEmpty()) {
            val lowerXmp = xmp.lowercase(Locale.ROOT)
            if (EditKeywords.SOFTWARE.any { it.length >= 4 && lowerXmp.contains(it) }) {
                return true
            }
            if (EditKeywords.XMP_MARKERS.any { lowerXmp.contains(it) }) {
                return true
            }
        }

        if (info.dateTime > 0L && info.dateTimeOriginal > 0L &&
            info.dateTime - info.dateTimeOriginal > ONE_MINUTE_MS
        ) {
            return true
        }

        if (EditKeywords.FILE_MARKERS.any { lowerName.contains(it) }) return true
        if (EditKeywords.FILE_PREFIXES.any { lowerName.startsWith(it) }) return true

        return false
    }
}
