package com.imagediff.data

/**
 * 编辑 / 修图 / 剪辑相关关键词表 —— 全部集中在这一处，方便后续补充。
 * 所有比较都按“转小写后 contains”进行，表里统一写小写。
 */
object EditKeywords {

    /**
     * ① 图片：EXIF Software 或 XMP 中出现这些软件名，说明被修图软件重新保存过。
     * 故意不收 "HDR+"、"Google"、"Camera" 这类相机原厂字样，避免误杀原片。
     */
    val SOFTWARE: List<String> = listOf(
        "photoshop",
        "lightroom",
        "snapseed",
        "meitu",
        "mtxx",
        "美图",
        "醒图",
        "xingtu",
        "picsart",
        "vsco",
        "gimp",
        "pixlr",
        "facetune",
        "afterlight",
        "adobe",
        "affinity photo",
        "capture one",
        "darktable",
        "rawtherapee",
        "luminar",
        "polarr",
        "泼辣",
        "黄油相机",
        "butter camera",
        "foodie",
        "b612",
        "camera360",
        "相机360",
        "retouch",
        "touchretouch",
        "pixomatic",
        "pitu",
        "天天p图",
        "美颜相机",
        "轻颜",
        "ulike",
        "剪映",
        "hypic",
        "wink",
        "photo editor",
        "photoeditor",
        "snapheal",
        "inpaint",
        "remover"
    )

    /**
     * ② 图片 / 动图：XMP 中的编辑历史与调色参数标记。
     */
    val XMP_MARKERS: List<String> = listOf(
        "xmpmm:history",
        "xmpmm:derivedfrom",
        "crs:",
        "photoshop:documentancestors",
        "lr:",
        "app:edited"
    )

    /**
     * ③ 视频：©too / encoder 等工具标签中的剪辑、转码软件。
     */
    val VIDEO_SOFTWARE: List<String> = listOf(
        "剪映",
        "jianying",
        "capcut",
        "快影",
        "kuaishou",
        "必剪",
        "bcut",
        "inshot",
        "vn视频剪辑",
        "vivacut",
        "videoleap",
        "quik",
        "premiere",
        "after effects",
        "final cut",
        "imovie",
        "filmora",
        "wondershare",
        "ffmpeg",
        "lavf",
        "libav",
        "handbrake",
        "davinci resolve",
        "openshot",
        "kdenlive",
        "shotcut",
        "movavi",
        "magisto",
        "轻剪辑",
        "快剪辑",
        "视频剪辑",
        "视频编辑"
    )

    /**
     * ④ 文件名里的编辑标记（图片 / 动图 / 视频通用）。
     */
    val FILE_MARKERS: List<String> = listOf(
        "-edited",
        "_edited",
        "(edited)",
        "edited)",
        "_edit",
        "-edit",
        "mtxx",
        "meitu",
        "美图",
        "醒图",
        "xingtu",
        "snapseed",
        "picsart",
        "vsco",
        "retouch",
        "修图",
        "调色",
        "美化",
        "滤镜",
        "精修",
        "_ps",
        "-ps",
        "_snap",
        "camera360",
        "相机360",
        "facetune",
        "ulike",
        "轻颜",
        "黄油",
        "pitu",
        "天天p图",
        "_hdr",
        "hdr_",
        "polarr",
        "泼辣",
        "剪映",
        "capcut",
        "快影",
        "必剪",
        "_剪辑",
        "_合成",
        "_导出"
    )

    /** ④ 文件名前缀标记：iOS 的 "IMG_E1234.JPG" 表示“编辑过的版本” */
    val FILE_PREFIXES: List<String> = listOf(
        "img_e",
        "pano_e"
    )
}
