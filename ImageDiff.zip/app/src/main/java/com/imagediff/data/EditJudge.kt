package com.imagediff.data

import android.content.Context
import android.util.Log
import com.imagediff.model.ImageMeta
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * “这条媒体是不是编辑/篡改过的”统一判定入口。
 *
 * 分派规则：
 *   · 视频（video/*）      → Mp4Inspector（©too/encoder 工具标签、mvhd 时间、XMP）
 *   · GIF / 动图           → GifInspector（注释块、XMP）
 *   · 其它图片             → ExifInspector（EXIF Software、DateTime、XMP）
 * 所有类型都先看文件名标记。
 *
 * 原则：**必须有明确证据**。读不出元数据 ⇒ 不算已编辑；解析出错 ⇒ 返回 false，不崩溃。
 */
object EditJudge {

    private const val TAG = "EditJudge"
    private const val ONE_MINUTE_MS = 60_000L

    suspend fun judge(context: Context, meta: ImageMeta): Boolean = withContext(Dispatchers.IO) {
        try {
            val name = meta.displayName.lowercase(Locale.ROOT)

            // ④ 文件名证据：所有类型通用，也最省 IO
            if (EditKeywords.FILE_MARKERS.any { name.contains(it) }) return@withContext true
            if (EditKeywords.FILE_PREFIXES.any { name.startsWith(it) }) return@withContext true

            val mime = meta.mimeType.lowercase(Locale.ROOT)
            when {
                meta.isVideo || mime.startsWith("video/") -> judgeVideo(context, meta)
                mime == "image/gif" || name.endsWith(".gif") || name.endsWith(".apng") ->
                    judgeGif(context, meta)

                else -> judgeImage(context, meta)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "已编辑判定失败（按未编辑处理）：${t.message}")
            false
        }
    }

    // ---------------------------------------------------------------- 视频

    private fun judgeVideo(context: Context, meta: ImageMeta): Boolean {
        val info = Mp4Inspector.read(context, meta.uri) ?: return false

        // ① ©too / encoder 工具标签
        val software = (info.softwareText ?: "").lowercase(Locale.ROOT)
        if (software.isNotEmpty() && EditKeywords.VIDEO_SOFTWARE.any { software.contains(it) }) {
            return true
        }

        // ① 补充：moov/udta 原始字节里出现剪辑、转码软件名
        //    （长度 ≥ 5 才匹配，避免 "vn"、"lr" 之类短词误判）
        val raw = (info.rawScanText ?: "").lowercase(Locale.ROOT)
        if (raw.isNotEmpty() &&
            EditKeywords.VIDEO_SOFTWARE.any { it.length >= 5 && raw.contains(it) }
        ) {
            return true
        }

        // ③ XMP 编辑历史
        val xmp = (info.xmp ?: "").lowercase(Locale.ROOT)
        if (xmp.isNotEmpty() && EditKeywords.XMP_MARKERS.any { xmp.contains(it) }) {
            return true
        }

        // ② mvhd 修改时间比（创建时间 + 时长）晚超过 1 分钟 → 被重新封装/剪辑过
        //    时间戳为 0 视为未知，不据此判定
        if (info.creationMs > 0L && info.modificationMs > 0L) {
            val base = info.creationMs + info.durationMs
            if (info.modificationMs - base > ONE_MINUTE_MS) return true
        }

        return false
    }

    // ---------------------------------------------------------------- GIF / 动图

    private fun judgeGif(context: Context, meta: ImageMeta): Boolean {
        val info = GifInspector.read(context, meta.uri) ?: return false
        val comment = (info.commentText ?: "").lowercase(Locale.ROOT)
        val xmp = (info.xmp ?: "").lowercase(Locale.ROOT)
        val blob = "$comment $xmp"
        if (blob.isBlank()) return false

        // 注释块 / XMP 里含修图软件名
        if (EditKeywords.SOFTWARE.any { it.length >= 4 && blob.contains(it) }) return true
        // XMP 编辑历史
        if (EditKeywords.XMP_MARKERS.any { blob.contains(it) }) return true
        return false
    }

    // ---------------------------------------------------------------- 普通图片

    private fun judgeImage(context: Context, meta: ImageMeta): Boolean {
        val info = ExifInspector.read(context, meta.uri)
        return ExifInspector.judgeEdited(info, meta.displayName)
    }
}
