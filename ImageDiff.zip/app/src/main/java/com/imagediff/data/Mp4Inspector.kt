package com.imagediff.data

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.charset.StandardCharsets

/**
 * 视频（ISO-BMFF：mp4 / mov / 3gp / m4v）元数据读取。
 *
 * 只按 box 头部跳读需要的部分：
 *   moov → mvhd（创建 / 修改时间、时长）、udta → ©too / ©enc（编码工具）、
 *   meta → ilst → data、uuid(XMP)、XMP_ 等。
 * mdat 直接按 size 跳过，所以 moov 在文件尾部也能读到；
 * 全程不把视频读进内存。
 */
object Mp4Inspector {

    private const val TAG = "Mp4Inspector"

    /** 1904-01-01 到 1970-01-01 的秒数 */
    private const val EPOCH_OFFSET_SECONDS = 2_082_844_800L

    private const val MAX_DEPTH = 8
    private const val MAX_RAW_SCAN = 512 * 1024
    private const val MAX_TEXT = 16 * 1024

    /** Adobe XMP 标准 uuid */
    private val XMP_UUID = byteArrayOf(
        0xBE.toByte(), 0x7A, 0xCF.toByte(), 0xCB.toByte(),
        0x97.toByte(), 0xA9.toByte(), 0x42, 0xE8.toByte(),
        0x9C.toByte(), 0x71, 0x99.toByte(), 0x94.toByte(),
        0x91.toByte(), 0xE3.toByte(), 0xAF.toByte(), 0xAC.toByte()
    )

    data class Mp4Info(
        val softwareText: String?,
        val xmp: String?,
        val creationMs: Long,
        val modificationMs: Long,
        val durationMs: Long,
        val rawScanText: String?
    )

    fun read(context: Context, uri: Uri): Mp4Info? {
        val target = try {
            MediaStore.setRequireOriginal(uri)
        } catch (t: Throwable) {
            uri
        }
        var pfd: ParcelFileDescriptor? = null
        var fis: FileInputStream? = null
        try {
            pfd = context.contentResolver.openFileDescriptor(target, "r") ?: return null
            fis = FileInputStream(pfd.fileDescriptor)
            return Parser(fis.channel).parse()
        } catch (t: Throwable) {
            Log.d(TAG, "解析视频元数据失败：${t.message}")
            return null
        } finally {
            try {
                fis?.close()
            } catch (_: Throwable) {
            }
            try {
                pfd?.close()
            } catch (_: Throwable) {
            }
        }
    }

    private class Parser(private val channel: FileChannel) {

        private val fileSize: Long = try {
            channel.size()
        } catch (t: Throwable) {
            0L
        }

        private var software: String? = null
        private var xmp: String? = null
        private var creationSeconds = 0L
        private var modificationSeconds = 0L
        private var durationMs = 0L
        private val rawScan = StringBuilder()

        fun parse(): Mp4Info {
            try {
                walk(0L, fileSize, 0)
            } catch (t: Throwable) {
                Log.d(TAG, "box 解析中断：${t.message}")
            }
            return Mp4Info(
                softwareText = software?.trim()?.takeIf { it.isNotEmpty() },
                xmp = xmp?.trim()?.takeIf { it.isNotEmpty() },
                creationMs = toEpochMs(creationSeconds),
                modificationMs = toEpochMs(modificationSeconds),
                durationMs = durationMs,
                rawScanText = rawScan.toString().takeIf { it.isNotEmpty() }
            )
        }

        private fun toEpochMs(seconds: Long): Long =
            if (seconds <= 0L) 0L else (seconds - EPOCH_OFFSET_SECONDS) * 1000L

        // ------------------------------------------------------------ box 遍历

        private fun walk(start: Long, end: Long, depth: Int) {
            if (depth > MAX_DEPTH || start < 0 || end > fileSize || start >= end) return
            var pos = start
            while (pos + 8 <= end) {
                val type = readType(pos) ?: return
                val size32 = readUInt32(pos)
                var headerSize = 8L
                var boxSize = size32
                if (size32 == 1L) {
                    if (pos + 16 > end) return
                    boxSize = readUInt64(pos + 8)
                    headerSize = 16L
                } else if (size32 == 0L) {
                    boxSize = end - pos
                }
                if (boxSize < headerSize || pos + boxSize > end) return

                val payloadStart = pos + headerSize
                val boxEnd = pos + boxSize

                when (type) {
                    "moov", "trak", "mdia", "minf", "stbl", "edts", "udta", "ilst", "dinf" -> {
                        if (type == "moov" || type == "udta") appendRawScan(payloadStart, boxEnd)
                        walk(payloadStart, boxEnd, depth + 1)
                    }

                    "meta" -> {
                        if (looksLikeBox(payloadStart, boxEnd)) {
                            walk(payloadStart, boxEnd, depth + 1)
                        } else {
                            walk(payloadStart + 4, boxEnd, depth + 1)
                        }
                    }

                    "mvhd" -> parseMvhd(payloadStart, boxEnd)

                    "\u00A9too", "\u00A9enc", "\u00A9swr" -> {
                        val text = readDataChildText(payloadStart, boxEnd)
                        if (!text.isNullOrBlank()) {
                            software = if (software.isNullOrBlank()) text else "$software $text"
                        }
                    }

                    "XMP_" -> {
                        xmp = readString(payloadStart, (boxEnd - payloadStart).toInt(), MAX_TEXT)
                    }

                    "uuid" -> {
                        if (boxEnd - payloadStart > 16 && uuidMatches(payloadStart)) {
                            xmp = readString(payloadStart + 16, (boxEnd - payloadStart - 16).toInt(), MAX_TEXT)
                        }
                    }
                }
                pos = boxEnd
            }
        }

        /** ilst 里的条目（©too 等）内部再套一个 data box */
        private fun readDataChildText(start: Long, end: Long): String? {
            var pos = start
            var guard = 0
            while (pos + 8 <= end && guard++ < 64) {
                val type = readType(pos) ?: return null
                val size32 = readUInt32(pos)
                var headerSize = 8L
                var boxSize = size32
                if (size32 == 1L) {
                    if (pos + 16 > end) return null
                    boxSize = readUInt64(pos + 8)
                    headerSize = 16L
                } else if (size32 == 0L) {
                    boxSize = end - pos
                }
                if (boxSize < headerSize || pos + boxSize > end) return null

                if (type == "data") {
                    // data: 4 字节 type indicator + 4 字节 locale + 正文
                    val textStart = pos + headerSize + 8
                    val len = (pos + boxSize - textStart).toInt()
                    if (len > 0) return readString(textStart, len, MAX_TEXT)
                    return null
                }
                pos += boxSize
            }
            return null
        }

        private fun parseMvhd(start: Long, end: Long) {
            val available = (end - start).coerceAtMost(40L).toInt()
            if (available < 20) return
            val buf = readBytes(start, available) ?: return
            val version = buf[0].toInt() and 0xFF
            if (version == 1) {
                if (buf.size < 32) return
                creationSeconds = getLong(buf, 4)
                modificationSeconds = getLong(buf, 12)
                val timescale = getInt(buf, 20).toLong() and 0xFFFFFFFFL
                val duration = getLong(buf, 24)
                if (timescale > 0L && duration > 0L) durationMs = duration * 1000L / timescale
            } else {
                creationSeconds = getInt(buf, 4).toLong() and 0xFFFFFFFFL
                modificationSeconds = getInt(buf, 8).toLong() and 0xFFFFFFFFL
                val timescale = getInt(buf, 12).toLong() and 0xFFFFFFFFL
                val duration = getInt(buf, 16).toLong() and 0xFFFFFFFFL
                if (timescale > 0L && duration > 0L) durationMs = duration * 1000L / timescale
            }
        }

        // ------------------------------------------------------------ 读取工具

        private fun appendRawScan(start: Long, end: Long) {
            if (rawScan.length >= MAX_RAW_SCAN) return
            val len = (end - start).coerceAtMost((MAX_RAW_SCAN - rawScan.length).toLong()).toInt()
            if (len <= 0) return
            val bytes = readBytes(start, len) ?: return
            // ISO_8859_1 一字节一字符，ASCII 关键字能安全匹配
            rawScan.append(String(bytes, StandardCharsets.ISO_8859_1))
        }

        private fun looksLikeBox(start: Long, end: Long): Boolean {
            if (start + 8 > end) return false
            val type = readType(start) ?: return false
            return type.all { it.code in 0x20..0x7E }
        }

        private fun uuidMatches(start: Long): Boolean {
            val bytes = readBytes(start, 16) ?: return false
            return bytes.contentEquals(XMP_UUID)
        }

        private fun readString(start: Long, length: Int, limit: Int): String? {
            if (length <= 0) return null
            val bytes = readBytes(start, length.coerceAtMost(limit)) ?: return null
            val text = String(bytes, StandardCharsets.UTF_8)
            val cleaned = text.filter { it == '\n' || it == '\t' || it.code in 0x20..0xFFFE }
            return cleaned.takeIf { it.isNotBlank() }
        }

        private fun readType(pos: Long): String? {
            val bytes = readBytes(pos, 4) ?: return null
            return String(bytes, StandardCharsets.ISO_8859_1)
        }

        private fun readUInt32(pos: Long): Long {
            val bytes = readBytes(pos, 4) ?: return 0L
            return (getInt(bytes, 0).toLong() and 0xFFFFFFFFL)
        }

        private fun readUInt64(pos: Long): Long {
            val bytes = readBytes(pos, 8) ?: return 0L
            return getLong(bytes, 0)
        }

        private fun readBytes(pos: Long, len: Int): ByteArray? {
            if (len <= 0 || pos < 0 || pos + len > fileSize) return null
            val buffer = ByteBuffer.allocate(len)
            var p = pos
            while (buffer.hasRemaining()) {
                val n = try {
                    channel.read(buffer, p)
                } catch (t: Throwable) {
                    return null
                }
                if (n <= 0) return null
                p += n
            }
            return buffer.array()
        }

        private fun getInt(bytes: ByteArray, offset: Int): Int {
            if (offset + 4 > bytes.size) return 0
            return ((bytes[offset].toInt() and 0xFF) shl 24) or
                ((bytes[offset + 1].toInt() and 0xFF) shl 16) or
                ((bytes[offset + 2].toInt() and 0xFF) shl 8) or
                (bytes[offset + 3].toInt() and 0xFF)
        }

        private fun getLong(bytes: ByteArray, offset: Int): Long {
            if (offset + 8 > bytes.size) return 0L
            var value = 0L
            for (i in 0 until 8) {
                value = (value shl 8) or (bytes[offset + i].toLong() and 0xFFL)
            }
            return value
        }
    }
}
