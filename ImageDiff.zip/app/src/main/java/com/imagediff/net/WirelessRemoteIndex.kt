package com.imagediff.net

import com.imagediff.model.RemoteIndex
import com.imagediff.model.RemoteIndexException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.LinkedHashMap

/**
 * 无线模式下的“对端指纹源”：把查询翻译成协议消息。
 *
 * 网络是串行的（Mutex 串起请求/响应），但 A 端本地算哈希是并行的。
 * 同尺寸的结果会缓存，避免重复请求。
 */
class WirelessRemoteIndex(private val connection: PeerConnection) : RemoteIndex {

    private val sendLock = Mutex()

    private val sizeMemo = object : LinkedHashMap<Long, Boolean>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, Boolean>): Boolean =
            size > MEMO_LIMIT
    }

    private val hashMemo = object : LinkedHashMap<Long, Set<String>>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, Set<String>>): Boolean =
            size > MEMO_LIMIT
    }

    override suspend fun hasSizeCandidate(size: Long): Boolean = sendLock.withLock {
        sizeMemo[size]?.let { return@withLock it }
        val response = call(JSONObject().put("t", "size").put("s", size))
        val has = response.optInt("n", 0) > 0
        sizeMemo[size] = has
        has
    }

    override suspend fun hashesForSize(size: Long): Set<String> = sendLock.withLock {
        hashMemo[size]?.let { return@withLock it }
        val response = call(JSONObject().put("t", "hash").put("s", size))
        val array = response.optJSONArray("h")
        val set = HashSet<String>(array?.length() ?: 0)
        if (array != null) {
            for (i in 0 until array.length()) {
                val hash = array.optString(i)
                if (hash.isNotEmpty()) set.add(hash)
            }
        }
        hashMemo[size] = set
        set
    }

    override suspend fun containsUnknownSizeHash(hash: String): Boolean = sendLock.withLock {
        val response = call(JSONObject().put("t", "find").put("h", hash))
        response.optBoolean("found", false)
    }

    override suspend fun close() {
        try {
            withContext(NonCancellable) {
                connection.request(JSONObject().put("t", "bye"))
            }
        } catch (_: Throwable) {
        }
        connection.close()
    }

    private suspend fun call(message: JSONObject): JSONObject {
        val response = try {
            connection.request(message)
        } catch (t: Throwable) {
            throw RemoteIndexException("与对端通信失败：${t.message}", t)
        }
        if (response.optString("t") == "err") {
            throw RemoteIndexException("对端返回错误：${response.optString("m")}")
        }
        return response
    }

    companion object {
        private const val MEMO_LIMIT = 512
    }
}
