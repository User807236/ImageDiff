package com.imagediff.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume

/** 网络里没有找到任何对端 */
class NoPeerException : IOException("没有发现对端设备")

/**
 * A 端发现对端：
 *   1) 优先 NsdManager(mDNS) 自动发现；
 *   2) 失败则回退扫描本子网的固定端口；
 *   3) 发现多台时取第一台。
 */
class PeerFinder(private val context: Context) {

    suspend fun find(): PeerConnection {
        val multicastLock = acquireMulticastLock()
        try {
            val viaNsd = withTimeoutOrNull(NSD_TOTAL_TIMEOUT_MS) { discoverViaNsd() }
            if (viaNsd != null) {
                val connection = tryHandshake(viaNsd.first, viaNsd.second)
                if (connection != null) {
                    Log.i(TAG, "通过 mDNS 连接成功：${viaNsd.first.hostAddress}:${viaNsd.second}")
                    return connection
                }
            }

            val scanned = scanSubnet()
            if (scanned != null) return scanned

            throw NoPeerException()
        } finally {
            try {
                multicastLock?.release()
            } catch (_: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------ mDNS 发现

    @Suppress("DEPRECATION")
    private suspend fun discoverViaNsd(): Pair<InetAddress, Int>? = coroutineScope {
        val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
            ?: return@coroutineScope null

        val found = Channel<NsdServiceInfo>(Channel.UNLIMITED)
        val resolveLock = Mutex()

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {
                Log.i(TAG, "mDNS 发现已启动")
            }

            override fun onDiscoveryStopped(serviceType: String) {}

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.w(TAG, "启动 mDNS 发现失败 errorCode=$errorCode")
                found.close()
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                if (serviceInfo.serviceName == NetIdentity.instanceName) return
                found.trySend(serviceInfo)
            }
        }

        try {
            nsdManager.discoverServices(
                NetIdentity.SERVICE_TYPE,
                NsdManager.PROTOCOL_DNS_SD,
                listener
            )
        } catch (t: Throwable) {
            Log.w(TAG, "discoverServices 异常：${t.message}")
            return@coroutineScope null
        }

        val result = try {
            withTimeoutOrNull(DISCOVERY_TIMEOUT_MS) {
                var answer: Pair<InetAddress, Int>? = null
                while (answer == null) {
                    val info = found.receive()
                    val resolved = resolveLock.withLock { resolve(nsdManager, info) } ?: continue
                    val host = resolved.host ?: continue
                    if (NetIdentity.isOwnAddress(host)) continue
                    answer = host to resolved.port
                }
                answer
            }
        } catch (t: Throwable) {
            Log.d(TAG, "mDNS 发现结束：${t.message}")
            null
        } finally {
            try {
                found.close()
            } catch (_: Throwable) {
            }
            try {
                nsdManager.stopServiceDiscovery(listener)
            } catch (_: Throwable) {
            }
        }
        result
    }

    @Suppress("DEPRECATION")
    private suspend fun resolve(nsdManager: NsdManager, info: NsdServiceInfo): NsdServiceInfo? =
        withTimeoutOrNull(RESOLVE_TIMEOUT_MS) {
            suspendCancellableCoroutine { continuation ->
                try {
                    nsdManager.resolveService(info, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                            if (continuation.isActive) {
                                runCatching { continuation.resume(null) }
                            }
                        }

                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            if (continuation.isActive) {
                                runCatching { continuation.resume(serviceInfo) }
                            }
                        }
                    })
                } catch (t: Throwable) {
                    if (continuation.isActive) {
                        runCatching { continuation.resume(null) }
                    }
                }
            }
        }

    // -------------------------------------------------------- 子网端口扫描

    private suspend fun scanSubnet(): PeerConnection? {
        val targets = NetIdentity.subnetTargets()
        if (targets.isEmpty()) return null
        Log.i(TAG, "开始扫描子网，共 ${targets.size} 个地址")

        val answer = AtomicReference<PeerConnection?>(null)
        coroutineScope {
            val semaphore = Semaphore(SCAN_CONCURRENCY)
            val jobs = targets.map { ip ->
                launch(Dispatchers.IO) {
                    semaphore.withPermit {
                        if (answer.get() != null) return@withPermit
                        val address = try {
                            InetAddress.getByName(ip)
                        } catch (t: Throwable) {
                            null
                        } ?: return@withPermit

                        for (port in NetIdentity.PORTS) {
                            if (answer.get() != null) return@withPermit
                            val connection = tryHandshake(address, port) ?: continue
                            if (answer.compareAndSet(null, connection)) {
                                Log.i(TAG, "扫描到对端：$ip:$port")
                                return@withPermit
                            }
                            connection.close()
                        }
                    }
                }
            }
            withTimeoutOrNull(SCAN_TIMEOUT_MS) {
                while (answer.get() == null) delay(120)
            }
            jobs.forEach { it.cancel() }
        }
        return answer.get()
    }

    private suspend fun tryHandshake(address: InetAddress, port: Int): PeerConnection? =
        withContext(Dispatchers.IO) {
            var socket: Socket? = null
            try {
                val raw = Socket()
                socket = raw
                raw.connect(InetSocketAddress(address, port), NetProtocol.CONNECT_TIMEOUT_MS)
                raw.soTimeout = NetProtocol.HANDSHAKE_TIMEOUT_MS
                raw.tcpNoDelay = true

                val connection = PeerConnection(raw)
                connection.send(JSONObject().put("t", "hello").put("v", NetProtocol.VERSION))
                val reply = connection.read() ?: throw IOException("对端无应答")
                if (reply.optString("t") != "welcome") throw IOException("对端不是本应用")

                raw.soTimeout = NetProtocol.SESSION_TIMEOUT_MS
                return@withContext connection
            } catch (t: Throwable) {
                try {
                    socket?.close()
                } catch (_: Throwable) {
                }
                return@withContext null
            }
        }

    private fun acquireMulticastLock(): WifiManager.MulticastLock? = try {
        val wifiManager =
            context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifiManager?.createMulticastLock(MULTICAST_TAG)?.apply {
            setReferenceCounted(false)
            acquire()
        }
    } catch (t: Throwable) {
        Log.w(TAG, "获取 MulticastLock 失败：${t.message}")
        null
    }

    companion object {
        private const val TAG = "PeerFinder"
        private const val MULTICAST_TAG = "imagediff"

        private const val NSD_TOTAL_TIMEOUT_MS = 9_000L
        private const val DISCOVERY_TIMEOUT_MS = 7_000L
        private const val RESOLVE_TIMEOUT_MS = 3_000L

        private const val SCAN_CONCURRENCY = 64
        private const val SCAN_TIMEOUT_MS = 25_000L
    }
}
