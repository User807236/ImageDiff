package com.imagediff.net

import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.UUID

/** 协议常量 */
object NetProtocol {
    /** 协议版本，握手时校验 */
    const val VERSION = 1

    /**
     * 会话读写超时。B 端给 3GB 大视频算哈希可能要好几分钟，
     * 因此这里放宽到 15 分钟，避免 A 端自己超时断开。
     */
    const val SESSION_TIMEOUT_MS = 900_000

    /** 握手超时 */
    const val HANDSHAKE_TIMEOUT_MS = 4_000

    /** 单次 TCP 连接超时（扫描子网用） */
    const val CONNECT_TIMEOUT_MS = 350
}

/** 本机网络身份：mDNS 实例名、端口、本机 IPv4 地址 */
object NetIdentity {

    /** mDNS 服务类型 */
    const val SERVICE_TYPE = "_imagediff._tcp"

    /** 固定端口（扫描子网时依次尝试） */
    val PORTS = intArrayOf(45871, 45872, 45873)

    /** 本机注册到 mDNS 的实例名；注册成功后由系统返回的真实名称覆盖 */
    @Volatile
    var instanceName: String = "IDX-" + UUID.randomUUID().toString().replace("-", "").take(10)
        internal set

    /** 本机所有非回环 IPv4 地址及前缀长度 */
    fun localIpv4(): List<Pair<Inet4Address, Int>> {
        val result = ArrayList<Pair<Inet4Address, Int>>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return result
            for (nif in interfaces) {
                try {
                    if (!nif.isUp || nif.isLoopback) continue
                } catch (_: Throwable) {
                    continue
                }
                for (interfaceAddress in nif.interfaceAddresses) {
                    val address = interfaceAddress.address
                    if (address is Inet4Address &&
                        !address.isLoopbackAddress &&
                        !address.isLinkLocalAddress
                    ) {
                        result.add(address to interfaceAddress.networkPrefixLength.toInt())
                    }
                }
            }
        } catch (t: Throwable) {
            // 某些系统限制网络接口枚举，忽略
        }
        return result
    }

    /** 判断某个地址是不是本机（避免连到自己） */
    fun isOwnAddress(address: InetAddress): Boolean {
        if (address.isLoopbackAddress) return true
        val host = address.hostAddress ?: return false
        return localIpv4().any { it.first.hostAddress == host }
    }

    /** 生成本子网待扫描的 IP 列表（默认按 /24，最多 1022 个） */
    fun subnetTargets(): List<String> {
        val targets = LinkedHashSet<String>()
        for ((address, prefix) in localIpv4()) {
            val bits = if (prefix in 16..30) prefix else 24
            val hostBits = 32 - bits
            val self = ipToInt(address)
            val network = self and (-1 shl hostBits)
            val hostCount = 1 shl hostBits
            val max = minOf(hostCount - 2, 1022)
            for (i in 1..max) {
                val candidate = network + i
                if (candidate == self) continue
                targets.add(intToIp(candidate))
            }
        }
        return targets.toList()
    }

    private fun ipToInt(address: Inet4Address): Int {
        val b = address.address
        return ((b[0].toInt() and 0xFF) shl 24) or
            ((b[1].toInt() and 0xFF) shl 16) or
            ((b[2].toInt() and 0xFF) shl 8) or
            (b[3].toInt() and 0xFF)
    }

    private fun intToIp(value: Int): String = buildString {
        append((value ushr 24) and 0xFF).append('.')
        append((value ushr 16) and 0xFF).append('.')
        append((value ushr 8) and 0xFF).append('.')
        append(value and 0xFF)
    }
}
