package com.imagediff.net

import android.content.Context
import android.os.Build
import android.util.Log
import com.imagediff.data.LocalHashProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * 无线模式下每台设备都在跑的服务端：
 * · 启动即监听固定端口并注册 mDNS
 * · 只应答“你有没有这个大小的文件 / 这些哈希”，从不传输文件内容
 * · 同一时刻只服务一个对端
 */
class WifiServer(
    private val context: Context,
    private val provider: LocalHashProvider,
    private val onSessionActive: (Boolean) -> Unit
) {

    private var serverSocket: ServerSocket? = null
    private var job: Job? = null
    private val registrar = NsdRegistrar(context)
    private val sessionMutex = Mutex()

    val isServing: Boolean get() = sessionMutex.isLocked

    fun start(scope: CoroutineScope) {
        if (job != null) return
        job = scope.launch(Dispatchers.IO) {
            val socket = bind()
            if (socket == null) {
                Log.w(TAG, "没有可用端口，无线监听未启动")
                return@launch
            }
            serverSocket = socket
            registrar.register(NetIdentity.instanceName, socket.localPort)
            Log.i(TAG, "无线监听已启动，端口 ${socket.localPort}")

            while (isActive) {
                val client = try {
                    socket.accept()
                } catch (t: Throwable) {
                    if (!isActive) break
                    delay(200)
                    continue
                }
                launch { serve(client) }
            }
        }
    }

    fun stop() {
        registrar.unregister()
        job?.cancel()
        job = null
        try {
            serverSocket?.close()
        } catch (_: Throwable) {
        }
        serverSocket = null
    }

    private fun bind(): ServerSocket? {
        for (port in NetIdentity.PORTS) {
            try {
                val socket = ServerSocket()
                socket.reuseAddress = true
                socket.bind(InetSocketAddress(port), 8)
                return socket
            } catch (t: Throwable) {
                Log.w(TAG, "端口 $port 绑定失败：${t.message}")
            }
        }
        return null
    }

    private suspend fun serve(socket: Socket) {
        if (!sessionMutex.tryLock()) {
            try {
                socket.close()
            } catch (_: Throwable) {
            }
            return
        }
        try {
            socket.soTimeout = NetProtocol.SESSION_TIMEOUT_MS
            socket.tcpNoDelay = true
            onSessionActive(true)
            val connection = PeerConnection(socket)
            Log.i(TAG, "对端已连接：${socket.inetAddress?.hostAddress}")

            while (true) {
                val message = connection.read() ?: break
                when (message.optString("t")) {
                    "hello" -> connection.send(
                        JSONObject()
                            .put("t", "welcome")
                            .put("v", NetProtocol.VERSION)
                            .put("name", deviceName())
                    )

                    "size" -> {
                        val size = message.optLong("s", 0L)
                        val count = provider.countBySize(size)
                        connection.send(
                            JSONObject()
                                .put("t", "size")
                                .put("s", size)
                                .put("n", count)
                        )
                    }

                    "hash" -> {
                        val size = message.optLong("s", 0L)
                        val hashes = provider.hashesBySize(size)
                        val array = JSONArray()
                        for (hash in hashes) array.put(hash)
                        connection.send(
                            JSONObject()
                                .put("t", "hash")
                                .put("s", size)
                                .put("h", array)
                        )
                    }

                    "find" -> {
                        val hash = message.optString("h")
                        val found = provider.containsUnknownSizeHash(hash)
                        connection.send(
                            JSONObject()
                                .put("t", "find")
                                .put("found", found)
                        )
                    }

                    "bye" -> break

                    else -> connection.send(
                        JSONObject().put("t", "err").put("m", "未知指令")
                    )
                }
            }
        } catch (t: Throwable) {
            Log.d(TAG, "会话结束：${t.message}")
        } finally {
            try {
                socket.close()
            } catch (_: Throwable) {
            }
            try {
                sessionMutex.unlock()
            } catch (_: Throwable) {
            }
            try {
                onSessionActive(false)
            } catch (_: Throwable) {
            }
        }
    }

    private fun deviceName(): String {
        val manufacturer = Build.MANUFACTURER ?: ""
        val model = Build.MODEL ?: ""
        return listOf(manufacturer, model)
            .filter { it.isNotBlank() }
            .joinToString(" ")
            .ifBlank { "Android" }
    }

    companion object {
        private const val TAG = "WifiServer"
    }
}
