package com.imagediff.net

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.Socket
import java.net.SocketTimeoutException

/**
 * 一条 TCP 连接上的“一行一个 JSON”收发器。
 * 同一个 Socket 只能有一个 PeerConnection（Reader 会预读缓冲）。
 */
class PeerConnection(private val socket: Socket) {

    private val reader = BufferedReader(
        InputStreamReader(socket.getInputStream(), Charsets.UTF_8),
        16 * 1024
    )
    private val writer = BufferedWriter(
        OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8),
        16 * 1024
    )

    suspend fun send(message: JSONObject) = withContext(Dispatchers.IO) {
        try {
            writer.write(message.toString())
            writer.write("\n")
            writer.flush()
        } catch (t: Throwable) {
            throw IOException("发送失败：${t.message}", t)
        }
    }

    /** 读一条消息；返回 null 表示对端已关闭连接 */
    suspend fun read(): JSONObject? = withContext(Dispatchers.IO) {
        try {
            var line = reader.readLine()
            while (line != null && line.isBlank()) {
                line = reader.readLine()
            }
            if (line == null) null else JSONObject(line)
        } catch (t: SocketTimeoutException) {
            throw IOException("对端响应超时", t)
        } catch (t: Throwable) {
            throw IOException("读取失败：${t.message}", t)
        }
    }

    /** 发一条并等一条回复 */
    suspend fun request(message: JSONObject): JSONObject {
        send(message)
        return read() ?: throw IOException("连接已断开")
    }

    fun close() {
        try {
            socket.close()
        } catch (t: Throwable) {
            Log.d("PeerConnection", "关闭连接异常：${t.message}")
        }
    }
}
