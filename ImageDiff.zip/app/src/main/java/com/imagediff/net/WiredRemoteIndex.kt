package com.imagediff.net

import android.net.Uri
import com.imagediff.data.SafSource
import com.imagediff.model.RemoteIndex
import com.imagediff.model.RemoteIndexException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.LinkedHashMap

/**
 * 有线模式下的“对端指纹源”：直接读 SAF 树里的文件算哈希。
 *
 * 与无线模式规则一致：先按大小预筛，只有同尺寸候选才算 SHA-256，结果缓存。
 */
class WiredRemoteIndex(
    private val treeUri: Uri,
    private val index: SafSource.Index,
    private val source: SafSource
) : RemoteIndex {

    private val mutex = Mutex()

    private val memo = LinkedHashMap<Long, Set<String>>()

    private var unknownSizeHashes: Set<String>? = null

    override suspend fun hasSizeCandidate(size: Long): Boolean {
        if (index.bySize[size]?.isNotEmpty() == true) return true
        // 对端存在“大小未知”的文件（部分 MTP 设备不提供 SIZE）时不能直接判缺失
        return index.unknownSize.isNotEmpty()
    }

    override suspend fun hashesForSize(size: Long): Set<String> = mutex.withLock {
        memo[size]?.let { return@withLock it }

        val ids = ArrayList<String>()
        index.bySize[size]?.let { ids.addAll(it) }
        ids.addAll(index.unknownSize)

        val result = HashSet<String>()
        val failures = hashAll(ids, result)
        if (ids.isNotEmpty() && result.isEmpty() && failures > 0) {
            throw RemoteIndexException("读取对端文件失败，请检查数据线是否被拔出")
        }

        memo[size] = result
        result
    }

    override suspend fun containsUnknownSizeHash(hash: String): Boolean {
        val hashes = unknownSizeHashes ?: mutex.withLock {
            unknownSizeHashes ?: computeUnknownSizeHashes()
        }
        return hashes.contains(hash)
    }

    private suspend fun computeUnknownSizeHashes(): Set<String> {
        val result = HashSet<String>()
        val failures = hashAll(index.unknownSize, result)
        if (index.unknownSize.isNotEmpty() && result.isEmpty() && failures > 0) {
            throw RemoteIndexException("读取对端文件失败，请检查数据线是否被拔出")
        }
        unknownSizeHashes = result
        return result
    }

    private suspend fun hashAll(ids: List<String>, out: MutableSet<String>): Int {
        var failures = 0
        for (documentId in ids) {
            val sha = try {
                source.sha256(treeUri, documentId)
            } catch (t: Throwable) {
                failures++
                null
            }
            if (sha != null) out.add(sha)
        }
        return failures
    }

    override suspend fun close() {
        // SAF 无需关闭连接
    }
}
