package com.imagediff.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log

/** 把本机服务注册到 mDNS，让对端能自动发现 */
class NsdRegistrar(private val context: Context) {

    private var registrationListener: NsdManager.RegistrationListener? = null

    fun register(name: String, port: Int) {
        val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return

        val serviceInfo = NsdServiceInfo().apply {
            serviceName = name
            serviceType = NetIdentity.SERVICE_TYPE
            setPort(port)
        }

        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {
                NetIdentity.instanceName = serviceInfo.serviceName
                Log.i(TAG, "mDNS 注册成功：${serviceInfo.serviceName}")
            }

            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.w(TAG, "mDNS 注册失败 errorCode=$errorCode")
            }

            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {
                Log.i(TAG, "mDNS 已注销")
            }

            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.w(TAG, "mDNS 注销失败 errorCode=$errorCode")
            }
        }

        try {
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, listener)
            registrationListener = listener
        } catch (t: Throwable) {
            Log.w(TAG, "registerService 异常：${t.message}")
        }
    }

    fun unregister() {
        val listener = registrationListener ?: return
        registrationListener = null
        val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
        try {
            nsdManager?.unregisterService(listener)
        } catch (t: Throwable) {
            Log.w(TAG, "unregisterService 异常：${t.message}")
        }
    }

    companion object {
        private const val TAG = "NsdRegistrar"
    }
}
