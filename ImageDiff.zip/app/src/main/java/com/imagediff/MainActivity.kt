package com.imagediff

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.imagediff.ui.ImageDiffTheme
import com.imagediff.ui.MainScreen
import com.imagediff.ui.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 边到边：系统栏透明、露出白色内容，图标强制深色
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        )
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }

        // 检测期间保持屏幕常亮（B 端保持前台也需要）
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            ImageDiffTheme {
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) {
                    viewModel.onPermissionResult()
                }

                val treeLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocumentTree()
                ) { uri ->
                    viewModel.onTreePicked(uri)
                }

                LaunchedEffect(Unit) {
                    val required = arrayOf(
                        Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.ACCESS_MEDIA_LOCATION
                    )
                    val allGranted = required.all {
                        ContextCompat.checkSelfPermission(this@MainActivity, it) ==
                            PackageManager.PERMISSION_GRANTED
                    }
                    if (allGranted) {
                        viewModel.onPermissionResult()
                    } else {
                        permissionLauncher.launch(required)
                    }
                }

                MainScreen(
                    vm = viewModel,
                    onStart = { viewModel.onStart { treeLauncher.launch(null) } }
                )
            }
        }
    }
}
