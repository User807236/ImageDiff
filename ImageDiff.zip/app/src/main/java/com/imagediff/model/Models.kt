package com.imagediff.model

import android.net.Uri
import java.io.IOException

/** 连接方式：无线（Wi-Fi + mDNS/TCP）/ 有线（USB + SAF） */
enum class LinkMode { WIRELESS, WIRED }

/** 一条待比对的媒体（图片 / GIF 动图 / 视频） */
data class ImageMeta(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val size: Long,
    val width: Int,
    val height: Int,
    val dateModified: Long,
    val isVideo: Boolean,
    val mimeType: String
) {
    /** 用作哈希缓存键、列表 key（图片与视频的 id 可能撞，必须用完整 URI） */
    val cacheKey: String get() = uri.toString()
}

/** 缺失项 */
data class MissingItem(
    val id: Long,
    val contentUri: String,
    val displayName: String,
    val size: Long,
    val isVideo: Boolean
)

/** 一次检测的最终统计 */
data class DiffSummary(
    val total: Int,
    val missing: Int,
    val skippedEdited: Int,
    val readErrors: Int
)

/**
 * 对端“指纹源”抽象：无线与有线两种实现，上层比对逻辑完全一致。
 */
interface RemoteIndex {
    /** 对端是否存在“字节数 == size”的候选（false 时可直接判缺失，无需算哈希） */
    suspend fun hasSizeCandidate(size: Long): Boolean

    /** 取对端所有“字节数 == size”的候选文件的 SHA-256（十六进制小写） */
    suspend fun hashesForSize(size: Long): Set<String>

    /** A 端拿不到文件大小（极少见）时的兜底查询 */
    suspend fun containsUnknownSizeHash(hash: String): Boolean

    suspend fun close()
}

/**
 * 对端读取类异常：必须中断整个检测任务。
 * （若当成单条媒体的读取失败而继续，会把剩下的全部误判成“缺失”）
 */
class RemoteIndexException(message: String, cause: Throwable? = null) : IOException(message, cause)
