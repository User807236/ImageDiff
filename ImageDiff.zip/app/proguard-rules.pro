# 本工程未开启代码混淆（isMinifyEnabled = false），此文件保留占位。
# 若将来开启混淆，请保留 ExifInterface 与 org.json 相关类：
-keep class androidx.exifinterface.** { *; }
